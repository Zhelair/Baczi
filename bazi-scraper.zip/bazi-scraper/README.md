# BaZi Knowledge Scraper

A local tool that populates your Supabase `bazi_knowledge` table with structured
BaZi rules from three sources — your own `.md` files, locally saved HTML pages,
and web scraping. Run it before bed, wake up to a smarter app.

## First-time setup

**1. Supabase table**
Run `supabase/bazi_knowledge.sql` in your Supabase SQL editor (once).

**2. Install Node dependencies**
```
npm install
```

**3. Create .env.local**
```
cp .env.example .env.local
```
Fill in `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `DEEPSEEK_API_KEY`.

## Run

```
npm run scrape
```

## Add your own knowledge

**Option A — Write `.md` files** (recommended, zero API cost)
Drop `.md` files anywhere in `knowledge/`. See `knowledge/README.md` for the format.
These are loaded directly — DeepSeek is not used, so it's instant and free.

**Option B — Save pages from your browser**
Open any BaZi article in Chrome, press `Ctrl+S`, save as "Webpage, HTML only".
Drop the `.html` file into `knowledge/html/`.
The scraper sends it through DeepSeek for extraction.

**Google Drive workflow**
Set `KNOWLEDGE_DIR` in `.env.local` to your synced GDrive folder:
```
KNOWLEDGE_DIR=C:\Users\You\Google Drive\BaZi-Rules
```
The scraper will read all `.md` files from there instead of the local `knowledge/` folder.
You can edit them in GDrive, sync, and run the scraper to update Supabase.

## What's included

| File | Purpose |
|------|---------|
| `scraper.mjs` | The scraper |
| `knowledge/clashes.md` | All 6 clashes pre-filled |
| `knowledge/combinations.md` | All 10 stem + 6 branch combinations |
| `knowledge/punishments.md` | 3 punishments + 4 self-punishments |
| `knowledge/daymaster-strength.md` | Strength assessment rules |
| `knowledge/luck-cycles.md` | Luck cycle reading principles |
| `supabase/bazi_knowledge.sql` | DB migration (run once) |
