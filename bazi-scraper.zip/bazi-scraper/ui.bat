@echo off
cd /d "%~dp0"
echo.
echo  ===================================
echo   BaZi Scraper UI
echo   Opening http://localhost:3456 ...
echo  ===================================
echo.

if not exist ".env.local" (
  echo  WARNING: .env.local not found.
  echo  Copy .env.example to .env.local and fill in your credentials first.
  echo  Then run the scraper from the UI.
  echo.
)

node server.mjs
