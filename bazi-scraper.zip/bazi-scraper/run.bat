@echo off
cd /d "%~dp0"
echo.
echo  ===========================
echo   BaZi Knowledge Scraper
echo  ===========================
echo.

if not exist ".env.local" (
  echo  ERROR: .env.local not found!
  echo  Copy .env.example to .env.local and fill in your credentials.
  echo.
  pause
  exit /b 1
)

npm run scrape
echo.
echo  Done! Press any key to close...
pause >nul
