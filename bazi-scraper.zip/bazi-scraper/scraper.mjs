/**
 * BaZi Knowledge Scraper
 *
 * Setup (one time):
 *   1. Run supabase/bazi_knowledge.sql in your Supabase SQL editor
 *   2. cp .env.example .env.local  and fill in your keys
 *   3. npm install
 *
 * Run:
 *   npm run scrape
 *
 * Sources (in order):
 *   1. KNOWLEDGE_DIR/*.md  — your curated rules, loaded directly (zero API cost)
 *   2. KNOWLEDGE_DIR/html/*.html — local pages saved from browser (DeepSeek)
 *   3. Web: fourpillars.ru, mingli.info (DeepSeek)
 *
 * KNOWLEDGE_DIR defaults to ./knowledge next to this file.
 * Set it in .env.local to point anywhere — e.g. your synced GDrive folder.
 */

import { createClient } from '@supabase/supabase-js'
import { readdir, readFile } from 'fs/promises'
import { join, extname, basename } from 'path'
import { fileURLToPath } from 'url'

const __dirname = fileURLToPath(new URL('.', import.meta.url))

const KNOWLEDGE_DIR = process.env.KNOWLEDGE_DIR || join(__dirname, 'knowledge')

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

// ── .md parser — direct load, no DeepSeek ────────────────────────────────────
//
// Format:
//   ## pattern_name
//   tags: Tag1, Tag2, Tag3
//   school: classical
//   confidence: high
//
//   Rule description text here.
//
//   ---

function parseMdRules(content, filePath) {
  const sourceUrl = `local:${basename(filePath)}`
  const rules = []
  const blocks = content.split(/^## /m).slice(1)

  for (const block of blocks) {
    const lines = block.split('\n')
    const pattern = lines[0].trim()
    if (!pattern) continue

    let tags = []
    let school = 'unknown'
    let confidence = 'medium'
    let descLines = []
    let inDesc = false

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i]
      if (line.startsWith('---')) break
      if (!inDesc) {
        if (line.startsWith('tags:')) { tags = line.replace('tags:', '').split(',').map(t => t.trim()).filter(Boolean); continue }
        if (line.startsWith('school:')) { school = line.replace('school:', '').trim(); continue }
        if (line.startsWith('confidence:')) { confidence = line.replace('confidence:', '').trim(); continue }
        if (line.trim() === '') { inDesc = true; continue }
      } else {
        descLines.push(line)
      }
    }

    const rule_text = descLines.join('\n').trim()
    if (!pattern || !rule_text) continue

    rules.push({
      pattern: pattern.slice(0, 200),
      rule_text: rule_text.slice(0, 1000),
      school: school.slice(0, 50),
      source_url: sourceUrl,
      confidence: ['high', 'medium', 'low'].includes(confidence) ? confidence : 'medium',
      tags,
      lang: 'en',
    })
  }
  return rules
}

// ── HTML → plain text ─────────────────────────────────────────────────────────

function htmlToText(html) {
  return html
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<nav[^>]*>[\s\S]*?<\/nav>/gi, '')
    .replace(/<footer[^>]*>[\s\S]*?<\/footer>/gi, '')
    .replace(/<header[^>]*>[\s\S]*?<\/header>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#\d+;/g, ' ')
    .replace(/\s+/g, ' ').trim()
}

function extractArticleLinks(html, baseUrl) {
  const links = new Set()
  const patterns = [
    /href="(\/(?:articles?|sections?|posts?|bazi|theory|knowledge)[^"]*?)"/gi,
    /href="(https?:\/\/(?:fourpillars\.ru|mingli\.info)\/[^"]*?)"/gi,
  ]
  for (const pat of patterns) {
    let m
    while ((m = pat.exec(html)) !== null) {
      const full = m[1].startsWith('http') ? m[1] : new URL(m[1], baseUrl).href
      if (!full.match(/\?|#/) && full !== baseUrl) links.add(full)
    }
  }
  return [...links]
}

// ── Fetch ─────────────────────────────────────────────────────────────────────

async function fetchPage(url, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; BaZiKnowledgeBot/1.0)',
          'Accept': 'text/html,application/xhtml+xml',
          'Accept-Language': 'ru,en;q=0.9',
        },
        signal: AbortSignal.timeout(15000),
      })
      if (!res.ok) { console.log(`  HTTP ${res.status} for ${url}`); return null }
      return await res.text()
    } catch (err) {
      console.log(`  Fetch attempt ${i + 1} failed: ${err.message}`)
      if (i < retries - 1) await sleep(2000 * (i + 1))
    }
  }
  return null
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

// ── DeepSeek rule extraction ──────────────────────────────────────────────────

async function extractRules(text, sourceUrl, lang) {
  const prompt = `You are a BaZi (Four Pillars of Destiny) expert. Extract structured BaZi rules from the article text below.

Source: ${sourceUrl}
Language: ${lang === 'ru' ? 'Russian' : 'English'}

Text:
"""
${text.slice(0, 5000)}
"""

Extract every distinct BaZi rule, interaction, or principle mentioned.

Respond ONLY with valid JSON:
{
  "rules": [
    {
      "pattern": "short identifier using pinyin e.g. Zi_Wu_clash or strong_Jia_daymaster",
      "rule_text": "clear description in English",
      "school": "classical",
      "confidence": "high",
      "tags": ["Zi", "Wu", "clash", "earthly_branch"]
    }
  ]
}

Pinyin reference — stems: Jia Yi Bing Ding Wu Ji Geng Xin Ren Gui
Branches: Zi Chou Yin Mao Chen Si Wu Wei Shen You Xu Hai
If nothing found: {"rules": []}`

  try {
    const res = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}` },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
        temperature: 0.2,
        max_tokens: 2000,
      }),
      signal: AbortSignal.timeout(30000),
    })
    if (!res.ok) { console.log(`  DeepSeek error ${res.status}`); return [] }
    const data = await res.json()
    const parsed = JSON.parse(data.choices[0].message.content)
    return (parsed.rules ?? []).map(r => ({
      pattern: String(r.pattern || '').slice(0, 200),
      rule_text: String(r.rule_text || '').slice(0, 1000),
      school: String(r.school || 'unknown').slice(0, 50),
      source_url: sourceUrl,
      confidence: ['high', 'medium', 'low'].includes(r.confidence) ? r.confidence : 'medium',
      tags: Array.isArray(r.tags) ? r.tags.map(t => String(t).slice(0, 50)) : [],
      lang,
    }))
  } catch (err) {
    console.log(`  Extraction error: ${err.message}`)
    return []
  }
}

// ── Supabase upsert ───────────────────────────────────────────────────────────

async function storeRules(rules) {
  if (rules.length === 0) return 0
  const { error } = await supabase
    .from('bazi_knowledge')
    .upsert(rules, { onConflict: 'pattern,source_url', ignoreDuplicates: false })
  if (error) { console.log(`  Supabase error: ${error.message}`); return 0 }
  return rules.length
}

// ── File helpers ──────────────────────────────────────────────────────────────

async function findFiles(dir, ext) {
  const results = []
  let entries
  try { entries = await readdir(dir, { withFileTypes: true }) } catch { return results }
  for (const e of entries) {
    const full = join(dir, e.name)
    if (e.isDirectory()) results.push(...await findFiles(full, ext))
    else if (e.isFile() && extname(e.name).toLowerCase() === ext) results.push(full)
  }
  return results
}

// ── Web targets ───────────────────────────────────────────────────────────────

const WEB_SOURCES = [
  { url: 'https://fourpillars.ru/articles', lang: 'ru', discover: true },
  ...Array.from({ length: 9 }, (_, i) => ({ url: `https://fourpillars.ru/sections/${i + 1}`, lang: 'ru', discover: true })),
  { url: 'https://mingli.info/articles', lang: 'ru', discover: true },
  { url: 'https://mingli.info/bazi-theory', lang: 'ru', discover: true },
  { url: 'https://mingli.info/theory', lang: 'ru', discover: true },
]

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  console.log('╔══════════════════════════════════════╗')
  console.log('║     BaZi Knowledge Scraper           ║')
  console.log('╚══════════════════════════════════════╝')
  console.log(`Time: ${new Date().toISOString()}`)
  console.log(`Knowledge dir: ${KNOWLEDGE_DIR}\n`)

  let total = 0

  // ── Stage 1: .md files (direct, free) ───────────────────────────────────────
  const mdFiles = (await findFiles(KNOWLEDGE_DIR, '.md'))
    .filter(f => basename(f) !== 'README.md')

  console.log(`── Stage 1: .md files (${mdFiles.length} found, no API cost) ──`)
  for (const file of mdFiles) {
    process.stdout.write(`  ${basename(file)} ... `)
    const content = await readFile(file, 'utf8')
    const rules = parseMdRules(content, file)
    const stored = await storeRules(rules)
    console.log(`${rules.length} rules stored`)
    total += stored
  }
  if (mdFiles.length === 0) console.log('  (none — add .md files to your knowledge folder)')

  // ── Stage 2: local HTML files (DeepSeek) ─────────────────────────────────────
  const htmlDir = join(KNOWLEDGE_DIR, 'html')
  const htmlFiles = await findFiles(htmlDir, '.html')

  console.log(`\n── Stage 2: local HTML files (${htmlFiles.length} found) ──`)
  for (const file of htmlFiles) {
    process.stdout.write(`  ${basename(file)} ... `)
    const html = await readFile(file, 'utf8')
    const text = htmlToText(html)
    if (text.length < 300) { console.log('too short, skipped'); continue }
    const rules = await extractRules(text, `local:${basename(file)}`, 'en')
    const stored = await storeRules(rules)
    console.log(`${rules.length} rules stored`)
    total += stored
  }
  if (htmlFiles.length === 0) console.log('  (none — save pages from browser and drop into knowledge/html/)')

  // ── Stage 3: web scraping ────────────────────────────────────────────────────
  console.log('\n── Stage 3: web scraping ──')
  const visited = new Set()

  for (const { url, lang, discover } of WEB_SOURCES) {
    if (visited.has(url)) continue
    visited.add(url)

    console.log(`\n  ${url}`)
    const html = await fetchPage(url)
    if (!html) continue

    total += await storeRules(await extractRules(htmlToText(html), url, lang))

    if (discover) {
      const links = extractArticleLinks(html, url)
      console.log(`  → ${links.length} articles discovered`)
      for (const link of links) {
        if (visited.has(link)) continue
        visited.add(link)
        process.stdout.write(`    ${link} ... `)
        const pageHtml = await fetchPage(link)
        if (!pageHtml) { console.log('failed'); continue }
        const text = htmlToText(pageHtml)
        if (text.length < 300) { console.log('too short'); continue }
        const rules = await extractRules(text, link, lang)
        const stored = await storeRules(rules)
        console.log(`${rules.length} rules`)
        total += stored
        await sleep(1500)
      }
    }
  }

  console.log('\n╔══════════════════════════════════════╗')
  console.log(`║  Done! Total rules stored: ${String(total).padEnd(9)}║`)
  console.log('╚══════════════════════════════════════╝')
}

main().catch(err => { console.error('Fatal:', err); process.exit(1) })
