@echo off
cd /d "%~dp0"
echo.
echo  =========================================
echo    BaZi Scraper  --  Nightly Task Manager
echo  =========================================
echo.

REM Check current task status
schtasks /query /tn "BaZi-Scraper-Nightly" >/dev/null 2>&1
if %errorlevel%==0 (
  echo  [STATUS]  Task is ACTIVE
  for /f "tokens=*" %%a in ('schtasks /query /tn "BaZi-Scraper-Nightly" /fo list ^| findstr "Next Run"') do echo  %%a
  echo.
  echo  What would you like to do?
  echo    1) Keep existing task
  echo    2) Remove the task
  echo    3) Recreate task with new settings
  echo.
  set /p CHOICE=Enter 1, 2 or 3:
  if "%CHOICE%"=="2" goto :remove
  if "%CHOICE%"=="3" goto :setup
  echo  OK, nothing changed.
  goto :end
) else (
  echo  [STATUS]  No task scheduled yet.
  echo.
  echo  This will run the scraper every night at 02:00 AM automatically.
  echo  Output is saved to:  %~dp0logs\nightly.log
  echo.
  set /p CONFIRM=Schedule nightly scraper? (Y/N):
  if /i not "%CONFIRM%"=="Y" goto :end
  goto :setup
)

:setup
REM Create logs folder if missing
if not exist "%~dp0logs" mkdir "%~dp0logs"

REM Delete old task if present
schtasks /delete /tn "BaZi-Scraper-Nightly" /f >/dev/null 2>&1

REM Create new task
schtasks /create /tn "BaZi-Scraper-Nightly" ^
  /tr "cmd /c cd /d \"%~dp0\" && node scraper.mjs >> \"%~dp0logs\nightly.log\" 2>&1" ^
  /sc daily /st 02:00 /f /rl highest

if %errorlevel%==0 (
  echo.
  echo  [OK]  Task scheduled: every night at 02:00 AM
  echo  [OK]  Logs saved to: %~dp0logs\nightly.log
  echo.
  echo  Useful commands:
  echo    View task:    schtasks /query /tn "BaZi-Scraper-Nightly" /fo list
  echo    Run now:      schtasks /run /tn "BaZi-Scraper-Nightly"
  echo    Remove:       schtasks /delete /tn "BaZi-Scraper-Nightly" /f
  echo    View log:     notepad "%~dp0logs\nightly.log"
) else (
  echo.
  echo  [ERROR] Could not create task.
  echo  Try right-clicking setup-task.bat and choosing "Run as administrator".
)
goto :end

:remove
schtasks /delete /tn "BaZi-Scraper-Nightly" /f
if %errorlevel%==0 (
  echo.
  echo  [OK]  Task removed. Scraper will no longer run automatically.
) else (
  echo.
  echo  [ERROR] Could not remove task. Try running as administrator.
)

:end
echo.
pause
