@echo off
cd /d "%~dp0"
echo.
echo  =====================================
echo   BaZi Scraper — Nightly Task Setup
echo  =====================================
echo.
echo  This will schedule the scraper to run every night at 02:00 AM.
echo.
set /p CONFIRM=Proceed? (Y/N):
if /i not "%CONFIRM%"=="Y" exit /b 0

schtasks /create /tn "BaZi-Scraper-Nightly" /tr "\"%~dp0run.bat\"" /sc daily /st 02:00 /f

if %errorlevel%==0 (
  echo.
  echo  Done! Scraper will run every night at 2:00 AM.
  echo  To remove: schtasks /delete /tn "BaZi-Scraper-Nightly" /f
) else (
  echo.
  echo  Failed to create task. Try running as Administrator.
)
echo.
pause
