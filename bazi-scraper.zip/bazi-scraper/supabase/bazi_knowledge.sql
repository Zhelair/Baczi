-- Run this ONCE in your Supabase SQL editor before first scraper run

CREATE TABLE IF NOT EXISTS bazi_knowledge (
  id           SERIAL PRIMARY KEY,
  pattern      TEXT        NOT NULL,
  rule_text    TEXT        NOT NULL,
  school       TEXT        NOT NULL DEFAULT 'unknown',
  source_url   TEXT        NOT NULL,
  confidence   TEXT        NOT NULL DEFAULT 'medium' CHECK (confidence IN ('high', 'medium', 'low')),
  tags         TEXT[]      NOT NULL DEFAULT '{}',
  lang         TEXT        NOT NULL DEFAULT 'en',
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Unique: no duplicate rules from same source
CREATE UNIQUE INDEX IF NOT EXISTS bazi_knowledge_pattern_source
  ON bazi_knowledge (pattern, source_url);

-- Fast tag overlap queries (used by the app's RAG lookup)
CREATE INDEX IF NOT EXISTS bazi_knowledge_tags_gin
  ON bazi_knowledge USING GIN (tags);
