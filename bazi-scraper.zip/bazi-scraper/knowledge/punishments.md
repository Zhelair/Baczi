# Three Punishments (三刑) and Self-Punishment

## Yin_Si_Shen_punishment
tags: Yin, Si, Shen, punishment, earthly_branch, wood, fire, metal
school: classical
confidence: high

Yin (Tiger), Si (Snake), and Shen (Monkey) form the Ungrateful Punishment (无恩之刑). Each branch harms the next in a triangle of disharmony. Associated with accidents, legal trouble, and disputes between people who should be allies. When all three appear in the chart or are activated by luck, the punishment is complete. Even two branches partially activate it.

---

## Chou_Wei_Xu_punishment
tags: Chou, Wei, Xu, punishment, earthly_branch, earth
school: classical
confidence: high

Chou (Ox), Wei (Goat), and Xu (Dog) form the Bullying Punishment (持势之刑). Three Earth storage vaults colliding. Stubbornness, power struggles, and chronic health issues (stomach, spleen). In the luck cycle, activating two of the three with the third in the natal chart triggers legal disputes and difficult authority conflicts.

---

## Zi_Mao_punishment
tags: Zi, Mao, punishment, earthly_branch, water, wood
school: classical
confidence: high

Zi (Rat) and Mao (Rabbit) form the Uncivilized Punishment (无礼之刑). Associated with disrespect of social norms, sexual misconduct, and boundary violations. Often appears in charts of people who struggle with rules and protocol. When activated in the luck cycle, lawsuits or social scandals can arise.

---

## Chen_Chen_self_punishment
tags: Chen, punishment, self_punishment, earthly_branch, earth
school: classical
confidence: high

Chen (Dragon) punishes itself when two Chen appear in the natal chart. The self-punishment is associated with self-sabotage — the person works against their own interests at critical moments. Health issues related to the stomach and digestion. The more Chen branches present, the more pronounced the self-defeating tendency.

---

## Wu_Wu_self_punishment
tags: Wu, punishment, self_punishment, earthly_branch, fire
school: classical
confidence: high

Wu (Horse) punishes itself when two Wu appear. Associated with excessive Fire energy turning inward: anxiety, heart issues, and impulsive self-harm (rushing into decisions that hurt oneself). During Wu years or months, this self-punishment activates strongly.

---

## You_You_self_punishment
tags: You, punishment, self_punishment, earthly_branch, metal
school: classical
confidence: high

You (Rooster) punishes itself. Metal cutting Metal — perfectionism taken to extremes, self-criticism, and respiratory issues. In luck cycles emphasizing You, the person may isolate or undermine their own achievements through excessive self-judgment.

---

## Hai_Hai_self_punishment
tags: Hai, punishment, self_punishment, earthly_branch, water
school: classical
confidence: high

Hai (Pig) self-punishment. Double Hai creates murky Water — confusion, poor boundaries, and difficulty making decisions. Associated with addictive tendencies and escapism. When the luck cycle or annual pillar activates this, the person may struggle to hold a clear direction.

---
