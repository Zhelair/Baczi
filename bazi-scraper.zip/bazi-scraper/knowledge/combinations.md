# Six Combinations (六合) and Three Combinations (三合)

## Zi_Chou_combine
tags: Zi, Chou, combine, earthly_branch, water, earth
school: classical
confidence: high

Zi (Rat) and Chou (Ox) form a Six Combination that transforms to Earth when Earth is the dominant element. Otherwise they are "bonded" — each branch loses some of its independent energy and is occupied by the other. This bonding can neutralize a Zi-Wu clash if Chou is present to hold Zi.

---

## Yin_Hai_combine
tags: Yin, Hai, combine, earthly_branch, wood, water
school: classical
confidence: high

Yin (Tiger) and Hai (Pig) combine and produce Wood. Hai Water nourishes Yin Wood. This combination strengthens Wood day masters when both appear in the chart or luck cycle. Often associated with literary talent and creative output.

---

## Mao_Xu_combine
tags: Mao, Xu, combine, earthly_branch, wood, earth, fire
school: classical
confidence: high

Mao (Rabbit) and Xu (Dog) combine and transform to Fire under the right conditions. Classical texts note this produces strong emotions and passion. The Xu vault opens and Mao Wood feeds hidden Fire, creating intensity in relationships.

---

## Chen_You_combine
tags: Chen, You, combine, earthly_branch, earth, metal
school: classical
confidence: high

Chen (Dragon) and You (Rooster) combine to produce Metal. Chen is the graveyard of Water but combines powerfully with You Metal. When this combination forms in the luck cycle for a Metal day master, a period of significant strengthening and achievement often follows.

---

## Si_Shen_combine
tags: Si, Shen, combine, earthly_branch, fire, metal, water
school: classical
confidence: high

Si (Snake) and Shen (Monkey) combine to produce Water. Both carry hidden Water (Ren in Shen, Geng/Bing/Wu in Si) and the combination draws out Water energy. Contradictory nature — they also clash weakly — making this one of the least stable combinations.

---

## Wu_Wei_combine
tags: Wu, Wei, combine, earthly_branch, fire, earth
school: classical
confidence: high

Wu (Horse) and Wei (Goat) combine to produce Fire or partial Earth. Both are Summer branches and this combination enhances Fire-Earth energy. For Fire or Earth day masters, this period in the luck cycle is often prosperous and active.

---

## Jia_Ji_combine
tags: Jia, Ji, combine, heavenly_stem, wood, earth
school: classical
confidence: high

Jia (Yang Wood) and Ji (Yin Earth) combine and transform to Earth when Earth is dominant in the chart. This combination weakens Jia day masters by binding their self-element. When the combination does not transform, Jia is "occupied" and loses its decisive, outward energy.

---

## Yi_Geng_combine
tags: Yi, Geng, combine, heavenly_stem, wood, metal
school: classical
confidence: high

Yi (Yin Wood) and Geng (Yang Metal) combine and transform to Metal. Metal controls Wood. When this combination transforms for a Yi day master, self-element is consumed. Associated with refinement, discipline, and sometimes health issues related to lungs and liver.

---

## Bing_Xin_combine
tags: Bing, Xin, combine, heavenly_stem, fire, metal, water
school: classical
confidence: high

Bing (Yang Fire) and Xin (Yin Metal) combine and transform to Water. Fire melts Metal into Water. For Bing day masters, this combination in the luck cycle or year produces Water — the Power/Officer star — often bringing career advancement but also scrutiny.

---

## Ding_Ren_combine
tags: Ding, Ren, combine, heavenly_stem, fire, water, wood
school: classical
confidence: high

Ding (Yin Fire) and Ren (Yang Water) combine and transform to Wood. Water meets candle flame and the result is Wood growth. Considered a romantic combination in classical texts. For Water day masters, meeting Ding produces the Resource star through transformation.

---

## Wu_Gui_combine
tags: Wu, Gui, combine, heavenly_stem, earth, water, fire
school: classical
confidence: high

Wu (Yang Earth) and Gui (Yin Water) combine and transform to Fire. The mountain dam meets the rain — and the result is warmth. For Earth day masters this combination brings Companion energy through Fire, creating both support and competition depending on chart balance.

---
