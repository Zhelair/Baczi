# Luck Cycles (大运) — Key Principles

## luck_cycle_general_reading
tags: luck_cycle, daymaster, strong, weak, output, wealth, power, resource
school: classical
confidence: high

The 10-year luck cycle is the dominant override on the natal chart. A favorable luck cycle can activate latent potential in a good natal chart and rescue a difficult one. An unfavorable cycle suppresses even a strong chart. Always read the natal chart AND the current luck cycle pillar together — the cycle stem and branch can combine with or clash against natal pillars, changing the chart's balance entirely.

---

## luck_cycle_stem_activates_natal
tags: luck_cycle, heavenly_stem, combine, clash, activation
school: classical
confidence: high

The luck cycle stem interacts with natal stems first (heavenly stem layer). A combining luck cycle stem can occupy or transform a natal stem, temporarily removing that element from play. A clashing luck cycle stem attacks a natal stem, creating turbulence in that element's stars for the full 10-year period.

---

## luck_cycle_branch_activates_natal
tags: luck_cycle, earthly_branch, combine, clash, activation
school: classical
confidence: high

The luck cycle branch interacts with natal branches (earthly branch layer). Branch combinations and clashes open or close the storage vaults (Chen Xu Chou Wei), releasing hidden stems. This secondary layer of interaction often produces the actual life events — the stem indicates the theme, the branch determines what concretely happens.

---

## annual_pillar_trigger
tags: year, annual, luck_cycle, activation, clash, combine
school: classical
confidence: high

The annual (yearly) pillar acts as the trigger on top of the luck cycle. An event forecast by the luck cycle typically manifests when the annual pillar's stem or branch combines with or clashes against a natal or luck cycle element. Without the annual trigger, the luck cycle's potential remains latent.

---

## favorable_unfavorable_cycle_assessment
tags: luck_cycle, favorable, unfavorable, daymaster, balance
school: classical
confidence: high

A luck cycle is favorable if it brings what the day master needs: a weak day master needs Resource and Companion cycles; a strong day master needs Output, Wealth, and Power cycles. The assessment is always relative to the current chart balance — the same cycle element can be favorable for one person and unfavorable for another depending on their natal chart.

---
