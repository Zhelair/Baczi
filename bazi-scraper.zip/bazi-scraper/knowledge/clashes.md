# Six Clashes (六冲)

## Zi_Wu_clash
tags: Zi, Wu, clash, earthly_branch, water, fire
school: classical
confidence: high

Zi (Rat / Water) and Wu (Horse / Fire) clash directly. Water attacks Fire. When this clash is activated by a luck cycle or annual pillar, it disrupts the palace it occupies: day branch = relationship and body; year branch = ancestry and early life; month branch = career and parents. Heart and kidney health may be affected for those with both in the natal chart.

---

## Chou_Wei_clash
tags: Chou, Wei, clash, earthly_branch, earth
school: classical
confidence: high

Chou (Ox) and Wei (Goat) both carry Earth but clash. This is an Earth-on-Earth clash that disturbs storage vaults. When activated, hidden stems inside both branches become unstable. Financial reserves (Chou stores wealth) can be disrupted.

---

## Yin_Shen_clash
tags: Yin, Shen, clash, earthly_branch, wood, metal
school: classical
confidence: high

Yin (Tiger / Wood) and Shen (Monkey / Metal) clash. Metal cuts Wood. Sudden changes in travel, movement, and transportation. Career shifts and unexpected relocations are common when this clash activates in the luck cycle.

---

## Mao_You_clash
tags: Mao, You, clash, earthly_branch, wood, metal
school: classical
confidence: high

Mao (Rabbit / Yin Wood) and You (Rooster / Metal) clash. Direct metal-over-wood. Legal disputes and document-related issues often arise. For day pillars with this clash, relationships carry a persistent tension that erupts during You or Mao years.

---

## Chen_Xu_clash
tags: Chen, Xu, clash, earthly_branch, earth
school: classical
confidence: high

Chen (Dragon) and Xu (Dog) both carry Earth and clash. Known as the "heaven clash" — both are storage vaults and their clash opens hidden stems violently. Spirit/mental instability and graveyard opening associations in classical texts.

---

## Si_Hai_clash
tags: Si, Hai, clash, earthly_branch, fire, water
school: classical
confidence: high

Si (Snake / Fire) and Hai (Pig / Water) clash. Water extinguishes Fire. Associated with disruption of intelligence and output stars. Movements, travel, and contracts can be upset when this clash appears in the luck cycle.

---
