# Day Master Strength Assessment

## strong_daymaster_general
tags: daymaster, strong, resource, companion
school: classical
confidence: high

A strong day master has abundant self-element (Resource and Companion stars fill month, year, or multiple pillars) and appears in its season. A strong day master benefits from Output, Wealth, and Power stars which drain and channel the excess energy productively. Too much self-element without outlets causes stagnation, arrogance, and blocked potential.

---

## weak_daymaster_general
tags: daymaster, weak, resource, companion
school: classical
confidence: high

A weak day master lacks supporting Resource and Companion stars and appears outside its productive season. A weak day master needs Resource stars (the element that produces the self-element) and Companion stars for support. Wealth, Output, and Power stars further drain a weak day master and are unfavorable unless balanced.

---

## Jia_strong_summer_weak
tags: Jia, daymaster, wood, fire, summer, weak
school: classical
confidence: high

Jia Wood day master born in summer (Si, Wu, Wei months) is weakened because Wood feeds Fire excessively. The Output star (Fire) drains strength. Unless the chart has strong Water (Resource) or Earth (Wealth) to balance, the day master struggles to sustain energy. Favorable luck cycles bring Water or Metal seasons.

---

## Geng_born_autumn_strong
tags: Geng, daymaster, metal, autumn, Shen, You, Xu, strong
school: classical
confidence: high

Geng Metal born in the autumn months (Shen, You, Xu) sits in its own season and is naturally strong. Needs Water Output to express its quality (Water = intelligence, writing, skills). Too much Earth Resource piles up and buries Metal. Best luck cycles are those with Water or Wood Wealth.

---

## Ren_born_winter_strong
tags: Ren, daymaster, water, winter, Hai, Zi, Chou, strong
school: classical
confidence: high

Ren Water born in winter (Hai, Zi, Chou months) is at its strongest. A flood chart — needs Earth Power/Wealth to dam the water and Wood Output to drain it. Without these, energy is uncontrolled. Highly productive people when properly channeled; unfocused and restless otherwise.

---

## fire_daymaster_water_clash
tags: Bing, Ding, daymaster, fire, water, clash, power, weak
school: classical
confidence: high

For a weak Fire day master, the Power star (Water) is threatening rather than empowering. Water controls Fire, and a weak Fire cannot handle strong Officer/Power energy without first being strengthened. Seeing strong Water in the luck cycle can cause career pressure, health stress, and relationship conflict before the day master is ready.

---
