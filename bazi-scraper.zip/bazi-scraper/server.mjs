/**
 * BaZi Scraper — Local UI Server
 *
 * Run:  npm run ui
 * Then open:  http://localhost:3456
 */

import { createServer } from 'http'
import { spawn } from 'child_process'
import { readFileSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const PORT = 3456
const HTML = readFileSync(join(__dirname, 'ui.html'), 'utf8')

let running = false

const server = createServer((req, res) => {
  // ── Serve main page ────────────────────────────────────────────────────────
  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
    res.end(HTML)
    return
  }

  // ── Status check ───────────────────────────────────────────────────────────
  if (req.method === 'GET' && req.url === '/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ running }))
    return
  }

  // ── SSE stream — runs the scraper and streams output ──────────────────────
  if (req.method === 'GET' && req.url === '/run') {
    if (running) {
      res.writeHead(409, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ error: 'Scraper already running' }))
      return
    }

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
    })

    const send = (type, text) => {
      res.write(`data: ${JSON.stringify({ type, text })}\n\n`)
    }

    running = true
    send('start', '▶ Starting BaZi Knowledge Scraper...\n')

    // Load .env.local values manually (node --env-file not available in all versions)
    let env = { ...process.env }
    try {
      const envFile = readFileSync(join(__dirname, '.env.local'), 'utf8')
      for (const line of envFile.split('\n')) {
        const trimmed = line.trim()
        if (!trimmed || trimmed.startsWith('#')) continue
        const eq = trimmed.indexOf('=')
        if (eq === -1) continue
        env[trimmed.slice(0, eq).trim()] = trimmed.slice(eq + 1).trim()
      }
    } catch {
      send('error', '✗ .env.local not found — please create it from .env.example\n')
      send('done', 'DONE')
      running = false
      res.end()
      return
    }

    const child = spawn('node', ['scraper.mjs'], {
      cwd: __dirname,
      env,
    })

    child.stdout.on('data', d => send('out', d.toString()))
    child.stderr.on('data', d => send('err', d.toString()))

    child.on('close', code => {
      running = false
      send('done', code === 0 ? '✓ Finished successfully!' : `✗ Exited with code ${code}`)
      res.end()
    })

    req.on('close', () => {
      if (running) child.kill()
    })

    return
  }

  res.writeHead(404)
  res.end()
})

server.listen(PORT, '127.0.0.1', () => {
  console.log(`\n  BaZi Scraper UI  →  http://localhost:${PORT}\n`)
  // Try to open browser automatically
  const open = process.platform === 'win32'
    ? ['cmd', ['/c', 'start', `http://localhost:${PORT}`]]
    : process.platform === 'darwin'
      ? ['open', [`http://localhost:${PORT}`]]
      : ['xdg-open', [`http://localhost:${PORT}`]]
  try {
    const { spawn: sp } = await import('child_process').catch(() => ({ spawn: null }))
    if (sp) sp(open[0], open[1], { detached: true, stdio: 'ignore' })
  } catch { /* ignore */ }
})

// Simple dynamic import trick for auto-open
import('child_process').then(({ spawn: sp }) => {
  const args = process.platform === 'win32'
    ? ['cmd', ['/c', 'start', `http://localhost:${PORT}`]]
    : process.platform === 'darwin'
      ? ['open', [`http://localhost:${PORT}`]]
      : ['xdg-open', [`http://localhost:${PORT}`]]
  try { sp(args[0], args[1], { detached: true, stdio: 'ignore' }) } catch { /* ignore */ }
}).catch(() => {})
