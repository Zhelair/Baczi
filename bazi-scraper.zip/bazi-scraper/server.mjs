/**
 * BaZi Scraper — Local UI Server  v1.1
 *
 * Run:  npm run ui
 * Then open:  http://localhost:3456
 *
 * Endpoints:
 *   GET    /             → UI HTML
 *   GET    /status       → { running: bool }
 *   GET    /run          → SSE stream of scraper output
 *   GET    /rules        → { rules, total }  (?search=&limit=&offset=)
 *   GET    /rules/stats  → { total, bySource: [{source,count}] }
 *   DELETE /rules/:id    → { ok: true }
 */

import { createServer } from 'http'
import { spawn } from 'child_process'
import { readFileSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const PORT = 3456
const HTML = readFileSync(join(__dirname, 'ui.html'), 'utf8')

let running = false
let _env = null

// ── Load .env.local once ─────────────────────────────────────────────────────
function loadEnv() {
  if (_env) return _env
  try {
    const file = readFileSync(join(__dirname, '.env.local'), 'utf8')
    const out = {}
    for (const line of file.split('\n')) {
      const t = line.trim()
      if (!t || t.startsWith('#')) continue
      const eq = t.indexOf('=')
      if (eq === -1) continue
      out[t.slice(0, eq).trim()] = t.slice(eq + 1).trim()
    }
    _env = out
  } catch { _env = null }
  return _env
}

// ── Minimal Supabase REST client ─────────────────────────────────────────────
async function sb(method, path, body) {
  const env = loadEnv()
  if (!env) throw new Error('.env.local not found')
  const url = `${env.SUPABASE_URL}/rest/v1${path}`
  const headers = {
    apikey: env.SUPABASE_ANON_KEY,
    Authorization: `Bearer ${env.SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
    Prefer: 'return=representation',
  }
  const r = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined })
  const txt = await r.text()
  if (!r.ok) throw new Error(`Supabase ${r.status}: ${txt}`)
  return txt ? JSON.parse(txt) : null
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function json(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' })
  res.end(JSON.stringify(data))
}

// ── Server ────────────────────────────────────────────────────────────────────
const server = createServer(async (req, res) => {
  const u = new URL(req.url, `http://localhost:${PORT}`)

  // Serve main page
  if (req.method === 'GET' && u.pathname === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
    res.end(HTML)
    return
  }

  // Status check
  if (req.method === 'GET' && u.pathname === '/status') {
    json(res, 200, { running })
    return
  }

  // Rules: stats
  if (req.method === 'GET' && u.pathname === '/rules/stats') {
    try {
      const rows = await sb('GET', '/bazi_rules?select=source')
      const map = {}
      for (const r of rows) map[r.source] = (map[r.source] || 0) + 1
      const bySource = Object.entries(map)
        .sort((a, b) => b[1] - a[1])
        .map(([source, count]) => ({ source, count }))
      json(res, 200, { total: rows.length, bySource })
    } catch (e) { json(res, 500, { error: e.message }) }
    return
  }

  // Rules: list with search + pagination
  if (req.method === 'GET' && u.pathname === '/rules') {
    try {
      const search = u.searchParams.get('search') || ''
      const limit  = Math.min(parseInt(u.searchParams.get('limit')  || '50'), 200)
      const offset = parseInt(u.searchParams.get('offset') || '0')
      const source = u.searchParams.get('source') || ''

      let qs = `/bazi_rules?select=id,rule_text,source,category&order=id.desc&limit=${limit}&offset=${offset}`
      if (search) qs += `&rule_text=ilike.*${encodeURIComponent(search)}*`
      if (source) qs += `&source=eq.${encodeURIComponent(source)}`

      const rows = await sb('GET', qs)

      // total count for pagination
      let cqs = `/bazi_rules?select=id`
      if (search) cqs += `&rule_text=ilike.*${encodeURIComponent(search)}*`
      if (source) cqs += `&source=eq.${encodeURIComponent(source)}`
      const all = await sb('GET', cqs)

      json(res, 200, { rules: rows, total: all.length, limit, offset })
    } catch (e) { json(res, 500, { error: e.message }) }
    return
  }

  // Rules: delete by id
  if (req.method === 'DELETE' && u.pathname.startsWith('/rules/')) {
    const id = u.pathname.replace('/rules/', '')
    if (!id || isNaN(Number(id))) { json(res, 400, { error: 'invalid id' }); return }
    try {
      await sb('DELETE', `/bazi_rules?id=eq.${id}`)
      json(res, 200, { ok: true })
    } catch (e) { json(res, 500, { error: e.message }) }
    return
  }

  // SSE stream — runs the scraper
  if (req.method === 'GET' && u.pathname === '/run') {
    if (running) {
      res.writeHead(409, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ error: 'Scraper already running' }))
      return
    }

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
    })

    const send = (type, text) => res.write(`data: ${JSON.stringify({ type, text })}\n\n`)

    const env = loadEnv()
    if (!env) {
      send('err', '✗ .env.local not found — please create it from .env.example\n')
      send('done', '✗ Aborted')
      res.end()
      return
    }

    running = true
    send('start', '▶ Starting BaZi Knowledge Scraper...\n')

    const child = spawn('node', ['scraper.mjs'], {
      cwd: __dirname,
      env: { ...process.env, ...env },
    })

    child.stdout.on('data', d => send('out', d.toString()))
    child.stderr.on('data', d => send('err', d.toString()))

    child.on('close', code => {
      running = false
      send('done', code === 0 ? '✓ Finished successfully!' : `✗ Exited with code ${code}`)
      res.end()
    })

    req.on('close', () => { if (running) child.kill() })
    return
  }

  res.writeHead(404)
  res.end()
})

server.listen(PORT, '127.0.0.1', () => {
  console.log(`\n  BaZi Scraper UI  →  http://localhost:${PORT}\n`)
})

import('child_process').then(({ spawn: sp }) => {
  const args = process.platform === 'win32'
    ? ['cmd', ['/c', 'start', `http://localhost:${PORT}`]]
    : process.platform === 'darwin'
      ? ['open', [`http://localhost:${PORT}`]]
      : ['xdg-open', [`http://localhost:${PORT}`]]
  try { sp(args[0], args[1], { detached: true, stdio: 'ignore' }) } catch { /* ignore */ }
}).catch(() => {})
